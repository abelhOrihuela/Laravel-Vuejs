<!DOCTYPE html>
<html>
<head>
	<title> Key Talent </title>

	<script src="/vendor/js/jquery.min.js"></script>
	<script src="/vendor/js/bootstrap.min.js"></script>

	<link rel="stylesheet" href="/vendor/css/bootstrap.min.css" media="screen" title="no title">
	<link rel="stylesheet" href="/css/keytalent.css">
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.8.23/themes/smoothness/jquery-ui.css">

	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

	<meta name="token" id="token" value="<?php echo e(csrf_token()); ?>">

</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
