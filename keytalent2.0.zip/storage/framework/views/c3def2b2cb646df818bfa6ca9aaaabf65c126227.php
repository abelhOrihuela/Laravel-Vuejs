


<div class="container-fluid">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="/">
      <img alt="Keytalentwtc" width="160" src="../img/keytalentwtc.png">
    </a>
    <ul class="nav navbar-nav navbar-right">

  <li><a href="/candidate/login"  class="btn btn-lg"><span class="glyphicon glyphicon-user"></span> Acceso candidato</a></li>
  <li><a href="/customer/login"  class="btn btn-lg"><span class="glyphicon glyphicon-stats"></span> Acceso cliente</a></li>
</div>

</div>

