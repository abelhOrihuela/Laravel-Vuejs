<script>
  export default{
    template: require('./a-loading.html')
  }
</script>
